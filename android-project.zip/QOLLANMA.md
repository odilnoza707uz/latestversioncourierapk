# BirZum Kuryer — APK yig'ish (faqat telefon bilan)

Kerak: GitHub akkaunt, **android-project.zip**, **build.yml**, Firebase'dan **google-services.json**.

## Ikki xil JSON — adashtirmang!
| Fayl | Qayerdan | Qayerga |
|---|---|---|
| **google-services.json** (ichida `"client"`, `"package_name"` bor) | Firebase → ⚙️ Project settings → **Your apps** → Android ilova → *google-services.json* | **GitHub'ga** |
| **...-firebase-adminsdk-....json** (ichida `"private_key"` bor) | Firebase → ⚙️ → **Service accounts** → *Generate new private key* | **Faqat saytga** (fcm.php). GitHub'ga YUKLAMANG |

## 1. Repozitoriy
1. github.com → **+** → **New repository** → nomi `birzum-courier` → **Private** → **Create repository**.

## 2. build.yml (eng muhim qadam)
1. Repozitoriyda **Add file → Create new file**.
2. Nom maydoniga aynan shuni yozing: `.github/workflows/build.yml`
   (boshidagi nuqta va qiyshiq chiziqlar bilan; har `/` dan keyin papka o'zi yaratiladi).
3. `build.yml` faylini telefonda oching → hammasini belgilab nusxalang → katta maydonga qo'ying.
4. **Commit changes** → yana **Commit changes**.

## 3. Ikki faylni yuklash
1. Repozitoriy bosh sahifasi → **Add file → Upload files**.
2. **android-project.zip** ni tanlang — **OCHMASDAN**, zipning o'zini.
3. **google-services.json** ni tanlang (nomi `google-services (1).json` bo'lib qolgan bo'lsa ham mayli).
4. **Commit changes**.

## 4. Yig'ish
1. **Actions** bo'limi (telefonda tepadagi "⋯" yoki brauzerni "Kompyuter versiyasi" rejimiga o'tkazing).
2. Chapda **APK yig'ish** → **Run workflow** → yashil **Run workflow**.
3. 5–10 daqiqa kuting. Yangilang.
4. ✅ yashil bo'lsa: ishga kiring → pastda **Artifacts** → **birzum-kuryer-apk** → yuklab oling →
   zipni oching → `app-release.apk` ni o'rnating.

## ❌ Qizil bo'lsa — menga nima yuborasiz
Ish (run) ichiga kiring. Sahifaning **tepasida (Summary)** o'zbekcha xulosa chiqadi:
- **"TUZATING: ..."** — yuklashda xato (noto'g'ri JSON, zip ochib yuborilgan va h.k.). Yozilganini bajaring, keyin **Re-run jobs**.
- **"Yig'ish yiqildi"** — qutidagi matnni **to'liq nusxalab** menga yuboring (yoki skrinshot). Shu yetarli, tuzatib beraman.

## 5. Birinchi ishga tushirish
1. Ilovani oching → chiqadigan ruxsatlarning **hammasiga** "Ruxsat berish":
   bildirishnoma → joylashuv → **"Doim ruxsat berish"** → batareya **"Cheklovsiz"** → ekranda ochilish.
2. Kuryer login, parol, PIN bilan kiring (admin: Kuryerlar → 🔑).
3. Admin → **Kuryerlar**: kuryer qatorida **📱** chiqsa — ilova ulangan.
4. **🔔** bosing → telefonda sirena chalishi kerak. Ilovadan chiqib (Home tugmasi) yana sinang.

## Signal kelmasa
- 📱 belgisi yo'q → ilovaga qayta kiring; internetni tekshiring.
- 🔔 xato beradi → xabardagi Firebase javobini menga yuboring.
  `SENDER_ID_MISMATCH` — ilovadagi google-services.json va saytdagi server kaliti **har xil** Firebase loyihasidan.
- Xato yo'q, lekin ovoz yo'q → Sozlamalar → Ilovalar → BirZum Kuryer → Batareya **"Cheklovsiz"**.
  Xiaomi/Redmi: **Avtostart** yoqing. Ilovani **"Majburan to'xtatish"** qilmang.

## Imzo kaliti (keyinroq, Google Play/RuStore va yangilash uchun)
1. Actions → **Imzo kaliti yaratish (bir marta)** → Run workflow → parol kiriting (eslab qoling).
2. Artifacts → **release-keystore** → `release.jks.b64` matnini nusxalang.
3. Settings → Secrets and variables → Actions → New repository secret:
   `KEYSTORE_BASE64` = o'sha matn, `KEYSTORE_PASSWORD` = parol.
4. `release.jks` ni xavfsiz saqlang — yo'qolsa ilovani yangilab bo'lmaydi.

## v1.9.0 — bitta ilova: kuryer yoki usta
Ilova endi ikki panelni ochadi: kuryer (sayt/c/) va usta (sayt/u/). Kirish sahifasida "Usta sifatida kirish" /
"Kuryer sifatida kirish" tugmalari bor. Tanlangan panel eslab qolinadi; fon joylashuvi va push tokeni shu panel
API'siga yuboriladi (window.BzNative.setPanel). Yangi versiyani yig'ib (versionCode oshiriladi) qayta tarqating.
