package uz.sdmsys.birzum.courier

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * Yangi buyurtma signali: ovoz ilova to'liq yopiq bo'lsa ham takrorlanib chaladi.
 * To'xtaydi: kuryer ilovani ochsa, "Ovozsiz" bossa yoki MAX_MS dan keyin.
 * Buyurtma olinmagan bo'lsa, server push'ni yana yuboradi va signal qayta davom etadi.
 */
class AlarmService : Service() {

    companion object {
        const val ACTION_STOP = "uz.sdmsys.birzum.courier.STOP_ALARM"
        private const val MAX_MS = 75_000L

        fun start(ctx: Context, title: String, body: String) {
            val i = Intent(ctx, AlarmService::class.java).putExtra("title", title).putExtra("body", body)
            ContextCompat.startForegroundService(ctx, i)
        }

        fun stop(ctx: Context) {
            try {
                ctx.stopService(Intent(ctx, AlarmService::class.java))
            } catch (e: Exception) {
            }
        }
    }

    private var player: MediaPlayer? = null
    private var wake: PowerManager.WakeLock? = null
    private var vibrator: Vibrator? = null
    private var oldVolume = -1
    private var lastBody = ""
    private val handler = Handler(Looper.getMainLooper())
    private val timeout = Runnable { finish(true) }
    private var fadeStep = 0
    private val fadeIn = object : Runnable {
        override fun run() {
            val p = player ?: return
            fadeStep++
            val vol = (0.35f + fadeStep * 0.065f).coerceAtMost(1.0f)
            try { p.setVolume(vol, vol) } catch (e: Exception) { return }
            if (vol < 1.0f) handler.postDelayed(this, 800L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            finish(false)
            return START_NOT_STICKY
        }
        val title = intent?.getStringExtra("title") ?: getString(R.string.new_order)
        val body = intent?.getStringExtra("body") ?: ""
        lastBody = body
        try {
            ServiceCompat.startForeground(
                this, Notif.ID_ALARM, Notif.alarm(this, title, body, foreground = true),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            )
        } catch (e: Exception) {
            // Tizim fon xizmatiga ruxsat bermadi: kamida ovozli bildirishnoma chiqadi
            Notif.notify(this, Notif.ID_ALARM, Notif.alarm(this, title, body, foreground = false))
            stopSelf()
            return START_NOT_STICKY
        }
        startSound()
        handler.removeCallbacks(timeout)
        handler.postDelayed(timeout, MAX_MS)
        return START_NOT_STICKY
    }

    private fun startSound() {
        if (player == null) {
            try {
                val am: AudioManager? = getSystemService(AudioManager::class.java)
                if (am != null) oldVolume = am.getStreamVolume(AudioManager.STREAM_ALARM)
                try {
                    if (am != null) {
                        val target = Math.round(am.getStreamMaxVolume(AudioManager.STREAM_ALARM) * 0.75f)
                        if (oldVolume < target) am.setStreamVolume(AudioManager.STREAM_ALARM, target, 0)
                    }
                } catch (e: Exception) {
                    // "Bezovta qilmang" rejimi ovozni o'zgartirishga ruxsat bermasligi mumkin
                }
                val mp = MediaPlayer()
                mp.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                val afd = resources.openRawResourceFd(R.raw.alarm)
                mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                mp.isLooping = true
                mp.prepare()
                mp.setVolume(0.35f, 0.35f)   // yumshoq boshlanib, ~8 soniyada to'liq balandlikka chiqadi
                mp.start()
                player = mp
                fadeStep = 0
                handler.post(fadeIn)
            } catch (e: Exception) {
                player = null
            }
        }
        if (wake == null) {
            val pm: PowerManager? = getSystemService(PowerManager::class.java)
            wake = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "birzum:alarm")
            wake?.acquire(MAX_MS + 5_000L)
        }
        if (vibrator == null) {
            vibrator = if (Build.VERSION.SDK_INT >= 31) {
                getSystemService(VibratorManager::class.java)?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Vibrator::class.java)
            }
            try {
                // yumshoq "tik-tik ... tinim" tebranishi (doimiy uzun tebranish o'rniga)
                val timings = longArrayOf(0, 180, 160, 180, 2000)
                val amps = intArrayOf(0, 140, 0, 140, 0)
                val v = vibrator
                if (v != null && v.hasAmplitudeControl()) v.vibrate(VibrationEffect.createWaveform(timings, amps, 0))
                else v?.vibrate(VibrationEffect.createWaveform(timings, 0))
            } catch (e: Exception) {
            }
        }
    }

    private fun release() {
        handler.removeCallbacks(timeout)
        handler.removeCallbacks(fadeIn)
        try {
            player?.stop()
        } catch (e: Exception) {
        }
        player?.release()
        player = null
        try {
            vibrator?.cancel()
        } catch (e: Exception) {
        }
        vibrator = null
        try {
            if (wake?.isHeld == true) wake?.release()
        } catch (e: Exception) {
        }
        wake = null
        if (oldVolume >= 0) {
            try {
                val am: AudioManager? = getSystemService(AudioManager::class.java)
                am?.setStreamVolume(AudioManager.STREAM_ALARM, oldVolume, 0)
            } catch (e: Exception) {
            }
            oldVolume = -1
        }
    }

    private fun finish(byTimeout: Boolean) {
        release()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        if (byTimeout) Notif.info(this, getString(R.string.missed_title), lastBody)
        stopSelf()
    }

    override fun onDestroy() {
        release()
        super.onDestroy()
    }
}
