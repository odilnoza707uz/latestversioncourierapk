package uz.sdmsys.birzum.courier

import android.content.ComponentName
import android.content.Intent
import android.os.Build

/**
 * Ba'zi telefonlar (Xiaomi, Huawei/Honor, Oppo/Realme, Vivo, Tecno/Infinix, Samsung) ilovani fonda
 * o'z cheklovlari bilan to'xtatadi va push kelmay qoladi. Bu yerda ularning sozlama oynalari.
 */
object Oem {
    private val brand get() = (Build.MANUFACTURER ?: "").lowercase()

    fun needs(): Boolean = listOf("xiaomi", "redmi", "poco", "huawei", "honor", "oppo", "realme", "oneplus", "vivo", "iqoo", "tecno", "infinix", "itel", "transsion", "samsung", "meizu", "asus", "letv")
        .any { brand.contains(it) }

    private fun cands(): List<ComponentName> = when {
        brand.contains("xiaomi") || brand.contains("redmi") || brand.contains("poco") -> listOf(
            ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"))
        brand.contains("huawei") || brand.contains("honor") -> listOf(
            ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
            ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"),
            ComponentName("com.hihonor.systemmanager", "com.hihonor.systemmanager.startupmgr.ui.StartupNormalAppListActivity"))
        brand.contains("oppo") || brand.contains("realme") || brand.contains("oneplus") -> listOf(
            ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"),
            ComponentName("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity"),
            ComponentName("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"))
        brand.contains("vivo") || brand.contains("iqoo") -> listOf(
            ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity"),
            ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"))
        brand.contains("tecno") || brand.contains("infinix") || brand.contains("itel") || brand.contains("transsion") -> listOf(
            ComponentName("com.transsion.phonemaster", "com.cyin.himgr.autostart.AutoStartActivity"))
        brand.contains("samsung") -> listOf(
            ComponentName("com.samsung.android.lool", "com.samsung.android.sm.battery.ui.BatteryActivity"),
            ComponentName("com.samsung.android.sm", "com.samsung.android.sm.battery.ui.BatteryActivity"))
        brand.contains("asus") -> listOf(ComponentName("com.asus.mobilemanager", "com.asus.mobilemanager.autostart.AutoStartActivity"))
        else -> emptyList()
    }

    /** Shu telefon uchun ehtimoliy sozlama oynalari (Android 11+ da tekshirib bo'lmaydi — navbat bilan ochib ko'riladi) */
    fun intents(): List<Intent> = cands().map { Intent().setComponent(it).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }

    /** Birinchi ochilgan oynani ochadi; hech biri bo'lmasa false */
    fun open(launch: (Intent) -> Unit): Boolean {
        for (i in intents()) {
            try { launch(i); return true } catch (e: Exception) { }
        }
        return false
    }
}
