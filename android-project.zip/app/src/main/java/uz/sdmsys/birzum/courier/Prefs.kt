package uz.sdmsys.birzum.courier

import android.content.Context

/** Kichik sozlamalar ombori: push tokeni, kirgan-kirmaganligi, sessiya cookie'si */
object Prefs {
    private const val FILE = "bz_courier"

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun token(c: Context): String = sp(c).getString("fcm_token", "") ?: ""
    fun setToken(c: Context, v: String) = sp(c).edit().putString("fcm_token", v).apply()

    fun tokenSent(c: Context): String = sp(c).getString("fcm_sent", "") ?: ""
    fun setTokenSent(c: Context, v: String) = sp(c).edit().putString("fcm_sent", v).apply()

    fun loggedIn(c: Context): Boolean = sp(c).getBoolean("logged_in", false)
    fun setLoggedIn(c: Context, v: Boolean) = sp(c).edit().putBoolean("logged_in", v).apply()

    fun cookie(c: Context): String = sp(c).getString("cookie", "") ?: ""
    fun setCookie(c: Context, v: String) = sp(c).edit().putString("cookie", v).apply()

    /** v1.9.0: qaysi panel ochiladi — "c/" (kuryer) yoki "u/" (usta). Fon so'rovlari ham shu panel API'siga boradi */
    fun panel(c: Context): String = sp(c).getString("panel", "c/").let { if (it == "u/") "u/" else "c/" }
    fun setPanel(c: Context, v: String) = sp(c).edit().putString("panel", if (v == "u/") "u/" else "c/").apply()

    fun oemDone(c: Context): Boolean = sp(c).getBoolean("oem_done", false)
    fun setOemDone(c: Context, v: Boolean) = sp(c).edit().putBoolean("oem_done", v).apply()
}
